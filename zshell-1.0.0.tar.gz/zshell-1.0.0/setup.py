from distutils.core import setup

setup(

    name= 'zshell',

    version= '1.0.0',

    py_modules =['zshell'],

    author= 'cedar12',

    author_email='cedar12.zxd@qq.com',

    url='https://github.com/cedar12/zshell.git',

    description= '快速构建命令行(shell)应用'

)